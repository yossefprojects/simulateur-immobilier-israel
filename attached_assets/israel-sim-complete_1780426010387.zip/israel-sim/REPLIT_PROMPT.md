# 🏗️ Simulateur Immobilier Israël — Prompt Replit

## Ce que tu dois construire

Une application web complète de simulation immobilière pour le marché israélien.
Déployable sur Replit, accessible depuis un navigateur, sans backend requis (tout en frontend).

---

## Stack technique pour Replit

- **React 18** (via CDN ou Vite template)
- **Tailwind CSS** (via CDN Play)
- **Lucide React** (icônes)
- Pas de base de données — toutes les données sont en mémoire (fichiers JS/TS)
- Pas d'authentification

> Si Replit propose un template, choisis **React + Vite** ou **React (JavaScript)**.
> Si tu pars de zéro, utilise le template **HTML/CSS/JS** et charge React via CDN.

---

## Structure de fichiers à créer

```
/
├── index.html
├── src/
│   ├── main.jsx
│   ├── App.jsx
│   ├── index.css
│   ├── data/
│   │   ├── villes.js
│   │   ├── coefficients.js
│   │   └── accords.js
│   ├── utils/
│   │   ├── formatters.js
│   │   └── calculators.js
│   └── components/
│       ├── ui.jsx               ← composants partagés
│       ├── EstimationTab.jsx
│       ├── UrbanismeTab.jsx
│       ├── InvestisseurTab.jsx
│       └── PromoteurTab.jsx
├── package.json
└── vite.config.js
```

---

## Données de référence

### src/data/villes.js

```javascript
export const VILLES = {
  tlv: {
    label: "Tel Aviv",
    quartiers: {
      "Florentin / Kerem HaTeimanim": { prixMoyen: 38000 },
      "Neve Tzedek":                  { prixMoyen: 52000 },
      "Rothschild / Centre":          { prixMoyen: 55000 },
      "Old North":                    { prixMoyen: 42000 },
      "Ramat Aviv":                   { prixMoyen: 35000 },
      "Jaffa":                        { prixMoyen: 28000 },
    }
  },
  herzliya: {
    label: "Herzliya",
    quartiers: {
      "Herzliya Pituach": { prixMoyen: 44000 },
      "Centre-ville":     { prixMoyen: 28000 },
      "Nordau":           { prixMoyen: 22000 },
    }
  },
  jerusalem: {
    label: "Jérusalem",
    quartiers: {
      "Rehavia":        { prixMoyen: 38000 },
      "Talbiyeh":       { prixMoyen: 40000 },
      "German Colony":  { prixMoyen: 35000 },
      "Har Nof":        { prixMoyen: 18000 },
      "Katamon":        { prixMoyen: 26000 },
    }
  },
  netanya: {
    label: "Netanya",
    quartiers: {
      "Ir Yamim":              { prixMoyen: 29000 },
      "Centre / bord de mer":  { prixMoyen: 24000 },
      "Poleg":                 { prixMoyen: 18000 },
      "Agamim":                { prixMoyen: 22000 },
    }
  },
  raanana: {
    label: "Ra'anana",
    quartiers: {
      "Centre Ra'anana": { prixMoyen: 25000 },
      "Kfar Saba Nord":  { prixMoyen: 18000 },
    }
  },
  haifa: {
    label: "Haïfa",
    quartiers: {
      "Carmel":          { prixMoyen: 20000 },
      "Merkaz HaCarmel": { prixMoyen: 22000 },
      "Hadar":           { prixMoyen: 14000 },
      "Bat Galim":       { prixMoyen: 16000 },
    }
  },
  beersheva: {
    label: "Beer Sheva",
    quartiers: {
      "Gimmel (ancien)": { prixMoyen: 8000  },
      "Nahal Beka":      { prixMoyen: 10000 },
      "Ramot":           { prixMoyen: 11000 },
    }
  },
}
```

---

### src/data/coefficients.js

```javascript
export const TYPES_PROJET = [
  { label: "Résidentiel classique",        value: 1.00 },
  { label: "Résidentiel luxe",             value: 1.30 },
  { label: "Programme neuf",               value: 1.10 },
  { label: "TAMA 38",                      value: 0.95 },
  { label: "Pinouï Binouï",               value: 1.05 },
  { label: "Mixte commerces + logements",  value: 1.15 },
]

export const coefSurface = (m2) => {
  if (m2 < 50)  return 1.22
  if (m2 < 70)  return 1.12
  if (m2 < 100) return 1.04
  if (m2 < 140) return 0.94
  return 0.87
}

export const coefMer = (km) => {
  if (km <= 0.2) return 1.35
  if (km <= 0.5) return 1.20
  if (km <= 1.5) return 1.10
  if (km <= 5)   return 1.02
  if (km <= 10)  return 0.96
  return 0.90
}

export const coefTransport = (km) => {
  if (km <= 0.3) return 1.08
  if (km <= 1)   return 1.04
  if (km <= 3)   return 1.00
  if (km <= 8)   return 0.97
  return 0.93
}

export const coefEtage = (etage) => {
  if (etage === 0) return 0.90
  if (etage <= 2)  return 0.97
  if (etage <= 8)  return 1.02
  if (etage <= 15) return 1.06
  return 1.12
}

export const EQUIPEMENTS = [
  { key: "ascenseur", label: "Ascenseur",        bonus: 0.05 },
  { key: "parking",   label: "Parking",          bonus: 0.10 },
  { key: "mamad",     label: "Mamad",            bonus: 0.06 },
  { key: "terrasse",  label: "Terrasse",         bonus: 0.07 },
  { key: "vueMer",    label: "Vue mer",          bonus: 0.20 },
  { key: "vueDeg",    label: "Vue dégagée",      bonus: 0.06 },
  { key: "gardien",   label: "Gardiennage",      bonus: 0.03 },
  { key: "piscine",   label: "Piscine commune",  bonus: 0.04 },
  { key: "gym",       label: "Salle de sport",   bonus: 0.03 },
]
```

---

### src/data/accords.js

```javascript
export const ACCORDS_MUNICIPAUX = {
  none:         { label: "Aucun projet / zone ordinaire",     coef: 1.00, score: 0  },
  tama38_etude: { label: "TAMA 38 — en étude",               coef: 1.05, score: 15 },
  tama38_ok:    { label: "TAMA 38 — approuvé",               coef: 1.15, score: 35 },
  pb_etude:     { label: "Pinouï-Binouï — en étude",         coef: 1.10, score: 25 },
  pb_ok:        { label: "Pinouï-Binouï — approuvé",         coef: 1.30, score: 55 },
  pc_ok:        { label: "Permis de construire obtenu",       coef: 1.40, score: 70 },
  chantier:     { label: "Chantier démarré",                  coef: 1.50, score: 85 },
}

export const STATUTS_PLAN = {
  approved:  { label: "Plan approuvé (Taba validée)",         coef: 1.00, score: 30 },
  pending:   { label: "Plan en cours d'approbation",          coef: 0.97, score: 20 },
  study:     { label: "En étude / avant-projet",              coef: 0.94, score: 10 },
  protected: { label: "Zone protégée / patrimoine",           coef: 0.85, score: 0  },
  renewal:   { label: "Zone de renouvellement urbain",        coef: 1.05, score: 25 },
  priority:  { label: "Secteur prioritaire municipal",        coef: 1.03, score: 22 },
}

export const STATUTS_PERMIS = {
  none:       { label: "Aucun permis déposé",                 coef: 1.00, score: 0   },
  depose:     { label: "Permis déposé (en instruction)",      coef: 1.05, score: 10  },
  accorde:    { label: "Permis accordé",                      coef: 1.15, score: 25  },
  opposition: { label: "Opposition en cours",                 coef: 0.93, score: -10 },
}

export const SOURCES_EXTERNES = [
  { label: "Mavat — Plans urbanistiques",           url: "https://mavat.iplan.gov.il"                                  },
  { label: "GovMap — Cadastre et zonage",           url: "https://www.govmap.gov.il"                                   },
  { label: "Nadlan Gov — Transactions officielles", url: "https://www.nadlan.gov.il"                                   },
  { label: "Israel Land Authority (ILA)",           url: "https://www.gov.il/en/departments/israel_land_authority"     },
  { label: "CBS Israël — Statistiques",             url: "https://www.cbs.gov.il"                                      },
  { label: "Banque d'Israël — Taux et rapports",    url: "https://www.boi.org.il/en"                                   },
]
```

---

## Fonctions de calcul

### src/utils/formatters.js

```javascript
export const fmt   = (n) => Math.round(n).toLocaleString("fr-FR")
export const fmtM  = (n) => n >= 1_000_000 ? (n / 1_000_000).toFixed(2) + "M₪" : fmt(n) + "₪"
export const fmtPct = (n, d = 2) => n.toFixed(d) + "%"
```

### src/utils/calculators.js

Implémenter les 4 fonctions suivantes :

#### calcEstimation(inputs)

```
inputs = {
  ville, quartier,
  distanceMer, distanceTransp,
  typeProjet,   // float (coefficient)
  surface, etage,
  equipements   // objet { ascenseur: bool, parking: bool, ... }
}

retourne {
  prixM2, prixTotal, coefTotal,
  waterfall: [{ label, coef, prixCumul }, ...]
}
```

Formule :
```
prixM2 = prixBaseQuartier
  × typeProjet
  × coefSurface(surface)
  × coefMer(distanceMer)
  × coefTransport(distanceTransp)
  × coefEtage(etage)
  × coefEquipements   // 1.0 + somme des bonus actifs
prixTotal = prixM2 × surface
```

#### calcUrbanisme(inputs)

```
inputs = {
  gush, helka, ville,
  surfTerrain, surfExist,
  planKey, etagesAut, cos,
  accordKey, permisKey,
  prixActuel
}

retourne {
  score (0–100), scoreLabel, scoreColor,
  coefTotal, prixProj, gainM2, gainPct,
  surfMax, droits,
  valActTot, valProjTot, plusValue
}
```

Score :
```
score = clamp(
  20
  + STATUTS_PLAN[planKey].score × 0.5
  + ACCORDS_MUNICIPAUX[accordKey].score × 0.6
  + STATUTS_PERMIS[permisKey].score × 0.4
  + (etagesAut > 15 ? 10 : etagesAut > 8 ? 5 : 0)
  + (droits > 500 ? 8 : droits > 200 ? 4 : 0),
  0, 100
)

scoreColor : vert (#0F6E56) si ≥70 | orange (#BA7517) si ≥45 | rouge (#993C1D) sinon
coefTotal  : STATUTS_PLAN[planKey].coef × ACCORDS_MUNICIPAUX[accordKey].coef × STATUTS_PERMIS[permisKey].coef
surfMax    : surfTerrain × cos
droits     : max(0, surfMax − surfExist)
```

#### calcInvestisseur(inputs)

```
inputs = {
  prix, apport (%), taux (%), duree (années),
  loyer, vacance (%), charges,
  reval (%), horizon (années)
}

mensualite = emprunt × (r×(1+r)^n) / ((1+r)^n − 1)
  où r = taux/12/100, n = duree×12

retourne {
  mensualite, rendBrut, rendNet,
  cfMensuel, tri, prixSortie, gainTotal,
  projection: [{ annee, valeur, cfCumul }]
}
```

#### calcPromoteur(inputs)

```
inputs = {
  surfTerrain, cos, ratioVend (%),
  prixVente, coutTerrain, coutConst,
  tauxFrais (%), tauxCommerc (%), tauxPortage (%)
}

surfTotale   = surfTerrain × cos
surfVendable = surfTotale × ratioVend/100
ca           = surfVendable × prixVente
coutConst    = surfTotale × coutConst/m²
frais        = coutConst × tauxFrais/100
commerc      = ca × tauxCommerc/100
portage      = (coutTerrain + coutConst) × tauxPortage/100
coutTotal    = coutTerrain + coutConst + frais + commerc + portage
margeBrute   = ca − coutTotal

retourne aussi sensitivity: variation de ±15% sur le prix de vente
```

---

## Interface utilisateur

### Navigation

4 onglets en haut de page :
1. **Estimation** — formulaire gauche / résultats droite
2. **Potentiel urbanistique** — score, accords municipaux, droits à construire
3. **Analyse investisseur** — métriques, cash-flow, projection
4. **Bilan promoteur** — bilan, marge, sensibilité

### Règles UX importantes

- Recalcul en temps réel à chaque changement d'input (pas de bouton "Calculer")
- Tous les nombres affichés passent par `fmt()` ou `fmtM()` — jamais de float brut
- Layout 2 colonnes sur desktop, 1 colonne sur mobile (responsive)
- Les sliders affichent leur valeur en temps réel à droite

### Composants à créer dans ui.jsx

```jsx
// SliderField — slider avec label et valeur affichée
<SliderField label="Distance à la mer" min={0} max={20} step={0.5}
  value={val} display={val + " km"} onChange={setVal} />

// SelectField — menu déroulant
<SelectField label="Ville" value={ville} options={[{value, label}]} onChange={setVille} />

// NumberField — input numérique
<NumberField label="Prix d'achat (₪)" value={prix} step={50000} onChange={setPrix} />

// MetricCard — carte de métrique
<MetricCard label="Rendement brut" value="4.20%" accent />

// DataTable — tableau label/valeur
<DataTable rows={[{ label, value, accent: "pos"|"neg"|"none", bold: true }]} />

// SectionTitle — titre de section
<SectionTitle>Localisation</SectionTitle>

// ResultBox — bloc résultat principal
<ResultBox main="2.34M₪" sub="Fourchette : ..." badges={[...]} />
```

### Onglet Urbanisme — composant ScoreRing

SVG circulaire animé affichant le score /100 :

```jsx
// Cercle SVG avec stroke-dasharray pour le remplissage
// r=34, circ=2πr
// dash = circ × score/100
// Couleur dynamique selon le score
// Valeur numérique centrée dans le cercle
```

Timeline d'avancement en 4 étapes :
- Taba / plan local
- Accord municipal
- Permis de construire
- Chantier démarré

Chaque étape a une icône : ✓ vert (fait) / ⏱ bleu (en cours) / ○ gris (en attente)

---

## Palette de couleurs recommandée

```css
/* Positif */   color: #0F6E56  (vert émeraude)
/* Négatif */   color: #993C1D  (orange brique)
/* Accent */    color: #185FA5  (bleu Israël)
/* Warning */   color: #BA7517  (ambre)
/* Texte */     color: #111827  (gris foncé)
/* Sous-titre */color: #6B7280  (gris moyen)
/* Surface */   background: #F9FAFB
/* Bordures */  border-color: #E5E7EB
```

---

## Configuration Replit

### package.json

```json
{
  "name": "israel-sim",
  "version": "0.1.0",
  "type": "module",
  "scripts": {
    "dev": "vite --host 0.0.0.0",
    "build": "vite build",
    "preview": "vite preview --host 0.0.0.0"
  },
  "dependencies": {
    "lucide-react": "^0.383.0",
    "react": "^18.3.1",
    "react-dom": "^18.3.1"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.3.1",
    "autoprefixer": "^10.4.19",
    "postcss": "^8.4.38",
    "tailwindcss": "^3.4.4"
  }
}
```

> ⚠️ Le flag `--host 0.0.0.0` est **obligatoire sur Replit** pour que le preview soit accessible.

### vite.config.js

```javascript
import { defineConfig } from "vite"
import react from "@vitejs/plugin-react"

export default defineConfig({
  plugins: [react()],
  server: {
    host: "0.0.0.0",
    port: 3000,
  },
})
```

### .replit (fichier de config Replit)

```toml
run = "npm run dev"
entrypoint = "index.html"

[nix]
channel = "stable-24_05"

[deployment]
run = ["sh", "-c", "npm run build && npm run preview"]
deploymentTarget = "static"
```

---

## Instructions pas à pas pour Replit

1. Crée un nouveau Repl — choisis le template **React Vite**
2. Supprime le contenu par défaut de `src/`
3. Crée les dossiers `src/data/`, `src/utils/`, `src/components/`
4. Crée les fichiers dans l'ordre suivant :
   - `src/data/villes.js`
   - `src/data/coefficients.js`
   - `src/data/accords.js`
   - `src/utils/formatters.js`
   - `src/utils/calculators.js`
   - `src/components/ui.jsx`
   - `src/components/EstimationTab.jsx`
   - `src/components/UrbanismeTab.jsx`
   - `src/components/InvestisseurTab.jsx`
   - `src/components/PromoteurTab.jsx`
   - `src/App.jsx`
   - `src/main.jsx`
   - `src/index.css`
5. Mets à jour `package.json` et `vite.config.js` avec les configs ci-dessus
6. Lance `npm install` dans le Shell Replit
7. Lance `npm run dev` — le preview s'ouvre dans l'onglet WebView

---

## Déploiement depuis Replit

Une fois l'app fonctionnelle :

1. Clique sur **Deploy** (bouton en haut à droite)
2. Choisis **Static deployment**
3. Build command : `npm run build`
4. Output directory : `dist`
5. L'URL publique sera du type : `https://israel-sim.ton-nom.repl.co`

---

## Checklist de validation

Avant de considérer le projet terminé, vérifie :

- [ ] Les 4 onglets sont navigables sans rechargement de page
- [ ] Le prix estimé se recalcule immédiatement à chaque slider/select
- [ ] Le score urbanistique change en temps réel selon les accords municipaux
- [ ] Aucun float brut n'est affiché (tous les nombres passent par `fmt()` ou `fmtM()`)
- [ ] Le layout est lisible sur mobile (1 colonne) et desktop (2 colonnes)
- [ ] Les liens vers Mavat, GovMap, Nadlan ouvrent dans un nouvel onglet
- [ ] La sensibilité promoteur affiche les 7 variations (-15% à +15%)
- [ ] Les valeurs positives sont vertes, négatives en orange/rouge

---

## Pour aller plus loin (optionnel)

- Ajouter un champ "Adresse" avec appel à l'API GovMap pour le géocodage automatique
- Connecter l'API Nadlan Gov pour les prix réels par immeuble
- Export PDF du bilan promoteur (via `jsPDF` ou `html2canvas`)
- Graphique de projection sur l'horizon (via `recharts` — disponible sur npm)
- Sauvegarde locale des simulations dans `localStorage`
- Partage d'une simulation via URL (paramètres dans le hash)
